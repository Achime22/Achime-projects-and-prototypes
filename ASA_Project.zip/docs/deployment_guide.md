
# Deployment Guide

## Prerequisites
- Docker and Docker Compose
- Python 3.8+
- Node.js and npm

## Steps
1. Clone the repository.
2. Set up environment variables in a `.env` file.
3. Build and run the containers:
   ```sh
   docker-compose up --build
   ```
4. Access the application at `http://localhost:8000`.

## Environment Variables
- `DJANGO_SECRET_KEY`: A secret key for Django.
- `DATABASE_URL`: PostgreSQL database URL.
- `STRIPE_SECRET_KEY`: Stripe API secret key.
